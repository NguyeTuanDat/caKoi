package uth.edu.cakoi.models;

import jakarta.persistence.*;

@Entity
@Table(name = "fish_tanks")
public class FishTank {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private double length;
    private double width;
    private double depth;

    // Thể tích có thể tính từ chiều dài x chiều rộng x chiều sâu, hoặc lưu riêng
    private double volume;

    // Các trường khác như số lượng cống thoát, công suất máy bơm, hình ảnh, etc.

    // Getters & Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getDepth() {
        return depth;
    }

    public void setDepth(double depth) {
        this.depth = depth;
    }

    public double getVolume() {
        return volume;
    }

    public void setVolume(double volume) {
        this.volume = volume;
    }

    // Optional: Tính tự động thể tích từ kích thước
    public void calculateVolumeFromDimensions() {
        this.volume = this.length * this.width * this.depth; // cm3 hoặc convert sang L
    }
}
