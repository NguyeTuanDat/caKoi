package uth.edu.cakoi.models;

import jakarta.persistence.*;

@Entity
@Table(name = "news_articles")
public class NewsArticle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String content;
    private String author;
    private String publishDate;

    // Getters and Setters
}
