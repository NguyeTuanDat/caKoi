package uth.edu.cakoi.models;

import jakarta.persistence.*;

@Entity
public class KoiFish {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // ID cá Koi (khóa chính)

    private String name; // Tên cá Koi
    private String gender; // Giới tính cá Koi (Đực, Cái)
    private String breed; // Giống cá Koi
    private int age; // Tuổi cá Koi
    private double weight; // Trọng lượng cá Koi (kg)
    private String tank; // Hồ cá đang ở

    // Constructor mặc định
    public KoiFish() {
    }

    // Constructor với các tham số
    public KoiFish(String name, String gender, String breed, int age, double weight, String tank) {
        this.name = name;
        this.gender = gender;
        this.breed = breed;
        this.age = age;
        this.weight = weight;
        this.tank = tank;
    }

    // Getter và Setter
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getTank() {
        return tank;
    }

    public void setTank(String tank) {
        this.tank = tank;
    }

    // Override toString() method để dễ dàng kiểm tra đối tượng
    @Override
    public String toString() {
        return "KoiFish [id=" + id + ", name=" + name + ", gender=" + gender + ", breed=" + breed + ", age=" + age
                + ", weight=" + weight + ", tank=" + tank + "]";
    }
}
