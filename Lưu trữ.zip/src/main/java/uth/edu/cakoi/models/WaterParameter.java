package uth.edu.cakoi.models;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "water_parameters")
public class WaterParameter {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime measuredAt;

    private double temperature;
    private double salinity;
    private double ph;
    private double o2;
    private double no2;
    private double no3;
    private double po4;

    @ManyToOne
    @JoinColumn(name = "fish_tank_id")
    private FishTank fishTank;

    // Getters & Setters
    // (Viết đầy đủ nếu bạn cần, mình có thể tạo luôn)
}
