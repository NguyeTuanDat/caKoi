package uth.edu.cakoi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uth.edu.cakoi.models.KoiFish;

public interface KoiFishRepository extends JpaRepository<KoiFish, Long> {
}
