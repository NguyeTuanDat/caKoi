package uth.edu.cakoi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uth.edu.cakoi.models.WaterParameter;

import java.util.List;

public interface WaterParameterRepository extends JpaRepository<WaterParameter, Long> {
    List<WaterParameter> findByFishTankId(Long fishTankId);
}
