package uth.edu.cakoi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uth.edu.cakoi.models.Permission;

public interface PermissionRepository extends JpaRepository<Permission, Long> {
}
