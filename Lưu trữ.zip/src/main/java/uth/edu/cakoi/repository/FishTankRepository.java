package uth.edu.cakoi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uth.edu.cakoi.models.FishTank;

public interface FishTankRepository extends JpaRepository<FishTank, Long> {
}
