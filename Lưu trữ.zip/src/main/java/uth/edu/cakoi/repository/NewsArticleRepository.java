package uth.edu.cakoi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uth.edu.cakoi.models.NewsArticle;

public interface NewsArticleRepository extends JpaRepository<NewsArticle, Long> {
}
