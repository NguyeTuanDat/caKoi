package uth.edu.cakoi.service;

import uth.edu.cakoi.models.FishTank;

import java.util.List;
import java.util.Optional;

public interface FishTankService {
    // Lấy tất cả các hồ cá
    List<FishTank> findAll();

    // Lấy hồ cá theo id
    Optional<FishTank> findById(Long id);

    // Lưu hồ cá mới hoặc cập nhật hồ cá
    FishTank save(FishTank fishTank);

    // Xóa hồ cá theo id
    void delete(Long id);

    // Tính toán lượng muối cần thiết cho hồ cá
    double calculateSaltAmount(FishTank fishTank);
}
