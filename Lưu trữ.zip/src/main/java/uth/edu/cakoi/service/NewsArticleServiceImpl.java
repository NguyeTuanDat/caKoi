package uth.edu.cakoi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uth.edu.cakoi.models.NewsArticle;
import uth.edu.cakoi.repository.NewsArticleRepository;

import java.util.List;
import java.util.Optional;

@Service
public
class NewsArticleServiceImpl implements NewsArticleService {

    @Autowired
    private NewsArticleRepository newsArticleRepository;

    @Override
    public List<NewsArticle> findAll() {
        return newsArticleRepository.findAll();
    }

    @Override
    public NewsArticle save(NewsArticle newsArticle) {
        return newsArticleRepository.save(newsArticle);
    }

    @Override
    public Optional<NewsArticle> findById(Long id) {
        return Optional.empty();
    }
}
