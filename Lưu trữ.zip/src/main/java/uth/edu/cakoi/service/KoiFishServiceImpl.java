package uth.edu.cakoi.service;

import uth.edu.cakoi.models.KoiFish;
import uth.edu.cakoi.repository.KoiFishRepository;
import uth.edu.cakoi.service.KoiFishService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class KoiFishServiceImpl implements KoiFishService {

    @Autowired
    private KoiFishRepository koiFishRepository;

    // Tìm tất cả cá Koi
    @Override
    public List<KoiFish> findAll() {
        return koiFishRepository.findAll();
    }

    // Tìm cá Koi theo ID
    @Override
    public KoiFish findById(Long id) {
        Optional<KoiFish> koiFish = koiFishRepository.findById(id);
        return koiFish.orElse(null); // Nếu không tìm thấy, trả về null
    }

    // Lưu cá Koi mới
    @Override
    public KoiFish save(KoiFish koiFish) {
        return koiFishRepository.save(koiFish);
    }

    // Cập nhật cá Koi
    @Override
    public KoiFish update(Long id, KoiFish koiFish) {
        if (koiFishRepository.existsById(id)) {
            koiFish.setId(id);
            return koiFishRepository.save(koiFish);
        }
        return null; // Nếu không tồn tại cá Koi với ID này, trả về null
    }

    // Xóa cá Koi theo ID
    @Override
    public void delete(Long id) {
        if (koiFishRepository.existsById(id)) {
            koiFishRepository.deleteById(id);
        }
    }
}
