package uth.edu.cakoi.service;

import uth.edu.cakoi.models.Role;

import java.util.List;
import java.util.Optional;

public interface RoleService {
    List<Role> getAllRoles();
    Optional<Role> getRoleById(Long id);
    Role saveRole(Role role);
    void deleteRoleById(Long id);
}
