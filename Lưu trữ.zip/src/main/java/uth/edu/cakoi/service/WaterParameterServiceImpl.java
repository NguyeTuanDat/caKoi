package uth.edu.cakoi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uth.edu.cakoi.models.WaterParameter;
import uth.edu.cakoi.repository.WaterParameterRepository;
import uth.edu.cakoi.service.WaterParameterService;

import java.util.List;
import java.util.Optional;

@Service
public class WaterParameterServiceImpl implements WaterParameterService {

    @Autowired
    private WaterParameterRepository repository;

    @Override
    public List<WaterParameter> findAll() {
        return repository.findAll();
    }

    @Override
    public List<WaterParameter> findByFishTankId(Long fishTankId) {
        return repository.findByFishTankId(fishTankId);
    }

    @Override
    public Optional<WaterParameter> findById(Long id) {
        return repository.findById(id);
    }

    @Override
    public WaterParameter save(WaterParameter parameter) {
        return repository.save(parameter);
    }

    @Override
    public void deleteById(Long id) {
        repository.deleteById(id);
    }
}
