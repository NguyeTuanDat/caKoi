package uth.edu.cakoi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uth.edu.cakoi.models.FishTank;
import uth.edu.cakoi.repository.FishTankRepository;
import uth.edu.cakoi.service.FishTankService;

import java.util.List;
import java.util.Optional;

@Service
public class FishTankServiceImpl implements FishTankService {

    @Autowired
    private FishTankRepository fishTankRepository;

    @Override
    public List<FishTank> findAll() {
        return fishTankRepository.findAll(); // Trả về tất cả các hồ cá
    }

    @Override
    public Optional<FishTank> findById(Long id) {
        return fishTankRepository.findById(id); // Tìm hồ cá theo ID
    }

    @Override
    public FishTank save(FishTank fishTank) {
        return fishTankRepository.save(fishTank); // Lưu hoặc cập nhật hồ cá
    }

    @Override
    public void delete(Long id) {
        fishTankRepository.deleteById(id); // Xóa hồ cá theo ID
    }

    @Override
    public double calculateSaltAmount(FishTank fishTank) {
        // Giả sử mỗi 1000L thể tích cần 1kg muối
        return fishTank.getVolume() / 1000.0;  // Tính lượng muối cần thiết dựa trên thể tích hồ
    }
}
