package uth.edu.cakoi.service;

import uth.edu.cakoi.models.KoiFish;

import java.util.List;

public interface KoiFishService {

    // Lấy tất cả cá Koi từ cơ sở dữ liệu
    List<KoiFish> findAll();

    // Tìm cá Koi theo ID
    KoiFish findById(Long id);

    // Lưu cá Koi mới hoặc cập nhật cá Koi đã tồn tại
    KoiFish save(KoiFish koiFish);

    // Cập nhật thông tin cá Koi
    KoiFish update(Long id, KoiFish koiFish);

    // Xóa cá Koi theo ID
    void delete(Long id);
}
