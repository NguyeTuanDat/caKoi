package uth.edu.cakoi.service;

import org.springframework.stereotype.Service;

@Service
public class CalculationService {

    // Tính lượng thức ăn cần thiết (g)
    public double calculateFoodAmount(double weightInGrams, double feedingRatePercent) {
        return weightInGrams * (feedingRatePercent / 100.0);
    }

    // Tính lượng muối cần thiết (g)
    public double calculateSaltAmount(double tankVolumeLiters, double desiredSalinityPercent) {
        return tankVolumeLiters * desiredSalinityPercent * 10;
    }
}
