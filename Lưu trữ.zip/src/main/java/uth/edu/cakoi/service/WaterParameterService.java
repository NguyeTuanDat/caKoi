package uth.edu.cakoi.service;

import uth.edu.cakoi.models.WaterParameter;

import java.util.List;
import java.util.Optional;

public interface WaterParameterService {
    List<WaterParameter> findAll();
    List<WaterParameter> findByFishTankId(Long fishTankId);
    Optional<WaterParameter> findById(Long id);
    WaterParameter save(WaterParameter parameter);
    void deleteById(Long id);
}
