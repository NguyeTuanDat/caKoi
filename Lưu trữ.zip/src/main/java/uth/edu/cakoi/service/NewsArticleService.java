package uth.edu.cakoi.service;

import uth.edu.cakoi.models.NewsArticle;

import java.util.List;
import java.util.Optional;

public interface NewsArticleService {
    List<NewsArticle> findAll();
    NewsArticle save(NewsArticle newsArticle);
    Optional<NewsArticle> findById(Long id); // ✅ Sửa chỗ này
}
