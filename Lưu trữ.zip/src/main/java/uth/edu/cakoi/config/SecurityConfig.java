package uth.edu.cakoi.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import uth.edu.cakoi.config.CustomUserDetailsService;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
@Configuration
public class SecurityConfig {

    private final CustomUserDetailsService uds;

    public SecurityConfig(CustomUserDetailsService uds) {
        this.uds = uds;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/","/koi_fish/**","/register", "/login", "/css/**", "/js/**").permitAll() // Cho phép truy cập những trang không cần đăng nhập
                        .requestMatchers("/admin", "/admin/**").hasRole("ADMIN")  // Chỉ ADMIN có thể truy cập /admin
                        .requestMatchers("/user", "/user/**" ).hasRole("USER")
                        .anyRequest().authenticated()  // Các request khác đều yêu cầu đăng nhập
                )
                .formLogin(form -> form
                        .loginPage("/login")  // Đường dẫn đến trang đăng nhập
                        .defaultSuccessUrl("/", true)  // Trang mặc định sau khi đăng nhập thành công
                        .loginProcessingUrl("/login")
                        .permitAll()  // Cho phép mọi người truy cập trang đăng nhập
                )
                .logout(l -> l
                        .logoutUrl("/logout")  // URL để logout
                        .permitAll()  // Cho phép logout mà không cần đăng nhập
                )
                .authenticationProvider(authProvider())  // Sử dụng provider xác thực tùy chỉnh
                .csrf(csrf -> csrf.disable());  // Tạm thời disable CSRF (nếu bạn cần thiết lập CSRF, có thể tùy chỉnh lại sau)

        return http.build();
    }

    // Hàm chuyển hướng người dùng dựa trên vai trò (role) của họ sau khi đăng nhập thành công
    private void loginSuccessHandler(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        var authorities = authentication.getAuthorities();
        System.out.println("Authorities: " + authorities);
        for (var auth : authorities) {
            if (auth.getAuthority().equals("ROLE_ADMIN")) {
                response.sendRedirect("/admin");
                return;
            } else if (auth.getAuthority().equals("ROLE_USER")) {
                response.sendRedirect("/user");
                return;
            }
        }
        System.out.println("No valid role found, redirecting to /login?error=true");
        response.sendRedirect("/login?error=true");
    }
    @Bean
    public DaoAuthenticationProvider authProvider() {
        DaoAuthenticationProvider p = new DaoAuthenticationProvider();
        p.setUserDetailsService(uds);  // Cung cấp service xác thực người dùng tùy chỉnh
        p.setPasswordEncoder(passwordEncoder());  // Mã hóa mật khẩu
        return p;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();  // Sử dụng BCrypt để mã hóa mật khẩu
    }
}






