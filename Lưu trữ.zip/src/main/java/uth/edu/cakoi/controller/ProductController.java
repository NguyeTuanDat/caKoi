package uth.edu.cakoi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import uth.edu.cakoi.models.Product;
import uth.edu.cakoi.service.ProductService;

@Controller
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping("/products")
    public String showProductList(Model model) {
        model.addAttribute("products", productService.findAll());
        return "product_list";
    }

    @GetMapping("/product/{id}")
    public String showProductDetails(@PathVariable Long id, Model model) {
        Product product = productService.findById(id).orElse(null);
        model.addAttribute("product", product);
        return "product_details";
    }

    @PostMapping("/product/{id}/purchase")
    public String purchaseProduct(@PathVariable Long id, Model model) {
        Product product = productService.findById(id).orElse(null);
        if (product != null && product.getStockQuantity() > 0) {
            product.setStockQuantity(product.getStockQuantity() - 1);
            productService.save(product);
            model.addAttribute("success", "Mua sản phẩm thành công!");
        } else {
            model.addAttribute("error", "Sản phẩm hết hàng!");
        }
        return "redirect:/products";
    }
}
