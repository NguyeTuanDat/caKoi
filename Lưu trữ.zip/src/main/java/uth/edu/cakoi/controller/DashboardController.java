package uth.edu.cakoi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import uth.edu.cakoi.service.FishTankService;
import uth.edu.cakoi.service.KoiFishService;

@Controller
public class DashboardController {

    @Autowired
    private FishTankService fishTankService;

    @Autowired
    private KoiFishService koiFishService;

    @GetMapping("/dashboard")
    public String showDashboard(Model model) {
        long totalFishTanks = fishTankService.findAll().size();
        long totalKoiFish = koiFishService.findAll().size();
        model.addAttribute("totalFishTanks", totalFishTanks);
        model.addAttribute("totalKoiFish", totalKoiFish);
        return "dashboard";
    }
}
