package uth.edu.cakoi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import uth.edu.cakoi.models.Role;
import uth.edu.cakoi.models.User;
import uth.edu.cakoi.repository.RoleRepository;
import uth.edu.cakoi.repository.UserRepository;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Controller
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    // GET: Hiển thị form đăng ký
    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    // POST: Xử lý dữ liệu đăng ký
    @PostMapping("/register")
    public String processRegister(@ModelAttribute("user") User user, Model model) {
        if (userRepository.findByUsername(user.getUsername()).isPresent()) {
            model.addAttribute("error", "Tên đăng nhập đã tồn tại!");
            return "register";
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setEnabled(true);

        Optional<Role> roleUser = roleRepository.findByName("USER");
        Set<Role> roles = new HashSet<>();
        roleUser.ifPresent(roles::add);
        user.setRoles(roles);

        userRepository.save(user);
        model.addAttribute("success", "Đăng ký thành công!");
        return "register";
    }
}
