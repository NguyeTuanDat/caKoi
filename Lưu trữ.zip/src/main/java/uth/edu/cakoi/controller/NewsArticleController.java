package uth.edu.cakoi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import uth.edu.cakoi.models.NewsArticle;
import uth.edu.cakoi.service.NewsArticleService;

@Controller
public class NewsArticleController {

    @Autowired
    private NewsArticleService newsArticleService;

    @GetMapping("/news")
    public String showNewsList(Model model) {
        model.addAttribute("articles", newsArticleService.findAll());
        return "news_list";
    }

    @GetMapping("/news/{id}")
    public String showNewsDetails(@PathVariable Long id, Model model) {
        NewsArticle article = newsArticleService.findById(id).orElse(null);
        model.addAttribute("article", article);
        return "news_details";
    }

    @GetMapping("/news/new")
    public String showNewsForm(Model model) {
        model.addAttribute("newsArticle", new NewsArticle());
        return "news_form";
    }

    @PostMapping("/news/new")
    public String saveNewsArticle(@ModelAttribute NewsArticle newsArticle, Model model) {
        newsArticleService.save(newsArticle);
        model.addAttribute("success", "Bài viết đã được đăng thành công!");
        return "redirect:/news";
    }
}
