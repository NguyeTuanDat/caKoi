package uth.edu.cakoi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import uth.edu.cakoi.service.CalculationService;

@Controller
@RequestMapping("/calculate")
public class CalculationController {

    @Autowired
    private CalculationService calculationService;

    @GetMapping
    public String showForm() {
        return "calculate/form";
    }

    @PostMapping("/result")
    public String calculate(
            @RequestParam double weight,
            @RequestParam double feedingRate,
            @RequestParam double tankVolume,
            @RequestParam double desiredSalinity,
            Model model
    ) {
        double foodAmount = calculationService.calculateFoodAmount(weight, feedingRate);
        double saltAmount = calculationService.calculateSaltAmount(tankVolume, desiredSalinity);

        model.addAttribute("foodAmount", foodAmount);
        model.addAttribute("saltAmount", saltAmount);

        return "calculate/result";
    }
}
