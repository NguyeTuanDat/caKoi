package uth.edu.cakoi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import uth.edu.cakoi.models.KoiFish;
import uth.edu.cakoi.service.KoiFishService;

@Controller
@RequestMapping("/koi_fish") // Đường dẫn chung cho các hành động liên quan đến cá Koi
public class KoiFishController {

    @Autowired
    private KoiFishService koiFishService;

    // Hiển thị danh sách cá Koi
    @GetMapping
    public String showAllKoiFish(Model model) {
        model.addAttribute("koiFishList", koiFishService.findAll());
        return "/koi_fish/list_koi_fish"; // Tên view hiển thị danh sách cá Koi
    }

    // Hiển thị form thêm cá Koi mới
    @GetMapping("/create")
    public String showAddForm(Model model) {
        model.addAttribute("koiFish", new KoiFish());
        return "/koi_fish/add_koi_fish"; // Tên view form thêm cá Koi
    }

    // Xử lý form thêm cá Koi mới
    @PostMapping("/add")
    public String addKoiFish(@ModelAttribute KoiFish koiFish) {
        koiFishService.save(koiFish); // Lưu cá Koi vào cơ sở dữ liệu
        return "/koi_fish/list_koi_fish"; // tên view
        // Sau khi thêm, chuyển hướng về danh sách cá Koi
    }

    // Hiển thị form chỉnh sửa cá Koi
    @GetMapping("/{id}/edit")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        KoiFish koiFish = koiFishService.findById(id); // Tìm cá Koi theo id
        model.addAttribute("koiFish", koiFish);
        return "edit_koi_fish"; // Tên view chỉnh sửa cá Koi
    }

    // Xử lý form chỉnh sửa cá Koi
    @PostMapping("/{id}")
    public String updateKoiFish(@PathVariable("id") Long id, @ModelAttribute KoiFish koiFish) {
        koiFish.setId(id); // Đảm bảo rằng id không bị thay đổi
        koiFishService.save(koiFish); // Cập nhật thông tin cá Koi trong cơ sở dữ liệu
        return "redirect:/koi_fish"; // Sau khi cập nhật, chuyển hướng về danh sách cá Koi
    }

    // Xóa cá Koi
    @PostMapping("/{id}/delete")
    public String deleteKoiFish(@PathVariable("id") Long id) {
        koiFishService.delete(id); // Xóa cá Koi theo id
        return "redirect:/koi_fish"; // Sau khi xóa, chuyển hướng về danh sách cá Koi
    }
}
