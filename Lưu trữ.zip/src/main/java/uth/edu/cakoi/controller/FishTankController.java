package uth.edu.cakoi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import uth.edu.cakoi.models.FishTank;
import uth.edu.cakoi.service.FishTankService;

@Controller
public class FishTankController {

    @Autowired
    private FishTankService fishTankService;

    @GetMapping("/fish_tank")
    public String showFishTankForm(Model model) {
        model.addAttribute("fishTank", new FishTank());
        return "fish_tank_form";
    }

    @PostMapping("/fish_tank")
    public String saveFishTank(@ModelAttribute FishTank fishTank, Model model) {
        fishTankService.save(fishTank);
        model.addAttribute("success", "Hồ cá đã được thêm thành công!");
        return "fish_tank_form";
    }
}
