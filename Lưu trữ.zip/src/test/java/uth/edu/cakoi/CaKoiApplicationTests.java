package uth.edu.cakoi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaKoiApplicationTests {

    @Test
    void contextLoads() {
    }

}
